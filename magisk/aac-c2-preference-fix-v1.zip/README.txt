AAC Codec2 Preference Fix  —— 修复「第三方相机录像无法保存视频」
================================================================
适用：OPPO Find X2 Pro (PDEM30) 刷入 ColorOS 16 (Android 16) 移植包之后

【真根因】(2026-10-04 定位)
  1) /system_ext/lib/libavenhancements.so（移植自 OnePlus 8T 的 ColorOS 16，
     即高通 AV Enhancements）在构造"自定义音频编码器候选列表"时会读取属性
     vendor.audio.c2.preferred：
        为 true  -> 打印 "CCodec preferred, skip creation of custom OMX audio encoders"
                    并返回空列表（交给系统按 mime 自动选 c2.android.aac.encoder）
        为 false -> 调用 AVConfigHelper::useHwAACEncoder()（读 vendor.audio.hw.aac.encoder，
                    本机为 true），把 OMX.qcom.audio.encoder.aac 放进候选列表
  2) 但 Find X2 Pro 的原厂 vendor 分区**从未在任何 media_codecs XML 里声明过**
     OMX.qcom.audio.encoder.aac（虽然 libOmxCore.so 的注册表里有它、libOmxAacEnc.so 也在），
     于是 MediaCodecList 查不到 -> MediaCodec::CreateByComponentName 拿不到 codecInfo
     -> ACodec: "Unexpected nullptr for codec information"
     -> StagefrightRecorder: "Failed to create audio encoder"
     -> 录像无音轨、文件无法保存。
  3) 附注：/vendor/etc/media_codecs.xml **根本不会被解析**；
     真正被 OMX 服务 (vendor.media.omx) 加载的是
     /vendor/etc/media_codecs_kona.xml（由 ro.media.xml_variant.codecs=_kona 推导），
     而 mediaserver 的 Codec2 路径加载的是 media_codecs_kona_vendor.xml。
     所以往 media_codecs.xml / media_codecs_oplus_c2.xml 里加声明都是无效的。
     另外 <Alias> 别名在 Android 16 上对 CreateByComponentName 也无效。

【本模块做什么】
  只做一件事：设置系统属性
        vendor.audio.c2.preferred = true
  不新增、不覆盖、不删除任何分区文件（纯属性修复）。

【效果】
  - Open Camera / 其它第三方相机录像（含 AAC 声音）可正常保存
  - 音频编码统一走 Codec2 软件编码器 c2.android.aac.encoder，无任何报错

【验证方法】
  adb shell dumpsys media.player | grep -A6 "audio/mp4a-latm"
  录像后 logcat 不应再出现：
     CreateByComponentName: name OMX.qcom.audio.encoder.aac
     E/ACodec: Unexpected nullptr for codec information
     E/StagefrightRecorder: Failed to create audio encoder

【卸载】
  Magisk 里删除本模块并重启即可恢复原状（属性自动消失）。
