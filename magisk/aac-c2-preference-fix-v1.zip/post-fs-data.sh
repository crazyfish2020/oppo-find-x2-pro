#!/system/bin/sh
# 双保险：即使 system.prop 未被处理，也在这里显式设置
MODDIR=${0%/*}
resetprop -n vendor.audio.c2.preferred true
